package com.ca.test11.controller;

import org.springframework.stereotype.Controller;
import org.springframework.web.bind.annotation.RequestMapping;

@Controller
public class TestController {

    /*
     * 
     * Controller에 있는 메서드를 우리가 이제는 호출하지 않을것임
     * 
     * 
     */

    // 해당메서드와 URL 요청(Path)을 연결하겠다 => 맵핑하겠다
    @RequestMapping("user/test1")
    public String test1() {
        System.out.println("test1이 호출되었을 때 실행될 코드");
        return "test1";
    }
}
