package com.ca.test11;

import org.springframework.boot.SpringApplication;
import org.springframework.boot.autoconfigure.SpringBootApplication;

@SpringBootApplication
public class Test11Application {

	public static void main(String[] args) {
		SpringApplication.run(Test11Application.class, args);
	}

}
